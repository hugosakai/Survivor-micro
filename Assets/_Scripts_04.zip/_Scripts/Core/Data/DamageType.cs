// _Scripts/Core/Data/DamageType.cs
public enum DamageType
{
    Normal = 0,
    Poison = 1,
    Slow = 2,
}