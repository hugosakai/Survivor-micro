public interface IAttackDriver
{
    public void StartFiring();
    public void StopFiring();
}
