//_Scripts/Core/Data/HealType.cs;
public enum HealType
{
    Instant = 0,
    Overtime = 1,
}
