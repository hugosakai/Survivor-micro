//_Scripts/Core/Data/HealSource.cs

public enum HealSource
{
    Potion = 0,
    Skill = 1,
}