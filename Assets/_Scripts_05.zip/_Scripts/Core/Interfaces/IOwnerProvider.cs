using UnityEngine;

public interface IOwnerProvider { Transform OwnerRoot { get; } }