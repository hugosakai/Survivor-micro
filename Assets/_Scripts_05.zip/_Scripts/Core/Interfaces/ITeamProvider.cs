public interface ITeamProvider
{
    public int TeamId { get; }
}
